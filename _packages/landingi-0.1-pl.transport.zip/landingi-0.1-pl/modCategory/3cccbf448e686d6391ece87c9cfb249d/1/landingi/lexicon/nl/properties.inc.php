<?php

$_lang['landingi_prop_pageId'] = 'De pagina id van de Landingi landingspagina.';