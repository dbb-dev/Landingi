<?php

$_lang['landingi_prop_pageId'] = 'The page id of the Landingi landing page.';