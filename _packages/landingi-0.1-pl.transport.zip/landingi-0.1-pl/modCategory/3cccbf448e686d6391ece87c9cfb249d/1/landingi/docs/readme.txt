--------------------
Landingi
--------------------
Version: 0.1.0
Author: DBB <info@dbb.nl>
--------------------

Landingi for MODx
A MODx Extra to integrate [Landingi](https://landingi.com/) landing pages. This Extra replace the PHP export function of Landingi.

Disclaimer
This Extra is developed by the initiative of DBB and is officially not  supported by Landingi.

Have fun!
This is a free extra and the code is publicly available for you to change.

Any questions or need help? Approach us for premium support @ info@dbb.nl.