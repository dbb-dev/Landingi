<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '0c3cfd0f72922f4f2bf7c63f6ef481a9',
      'native_key' => 'landingi',
      'filename' => 'modNamespace/555d3569e8e54421a3af265e31867f31.vehicle',
      'namespace' => 'landingi',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '863c08e30f1378dfffd1c43f51921c61',
      'native_key' => NULL,
      'filename' => 'modCategory/55ce70b1448a83e5bc1ee014d153cbb4.vehicle',
      'namespace' => 'landingi',
    ),
  ),
);